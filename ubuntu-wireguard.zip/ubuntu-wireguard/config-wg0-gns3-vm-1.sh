#!/bin/bash
# config-wg0-gns3-vm-1.sh
# usage: this need to be called with sudo
# description: Creates a wireguard public key and wireguard private key
# and then writes part of the wg0.conf. It can not write
# the entire wg0.conf because it does not know the client public key.
# Lastly, it configures IP forwarding for subnets behind this server.

set -e

if [ "$EUID" -ne 0 ] ; then
  printf "Please run this as root\n"
  exit 1
fi
if [ -z "$1" ] ; then
  printf "this script requires peer's ip address and port\n"
  exit 1
fi
if [ -z "$2" ] ; then
  printf "this script requires peer's public key filename\n"
  exit 1
fi

peer_tcp=$1
public_basename=$2

peer_url="http://$peer_tcp/$public_basename"
printf "\n*** Trying to connect to $peer_url ***\n"
peerpublickey=$(wget -q --connect-timeout=5 --tries=1 -O - $peer_url)

if [ -z "$peerpublickey" ] ; then
    printf "\nERROR: unable to connect to $peer_tcp\n"
    exit 1
else
    printf "\n*** Sucessfully retrieved peer's public key ***\n"
fi

wg_udpport=51820
private=$(cat /etc/wireguard/privatekey)

# Add allow for wireguard udp port
printf "\n*** Adding new ufw allow rules ***\n"
ufw allow $wg_udpport/udp comment "Wireguard UDP Port"
sudo ufw status numbered verbose

cat << EOF > /etc/wireguard/wg0.conf
[Interface]
## This host's wireguard (wg0) ip address ##
Address = 172.16.253.1/24

## This host's wireguard private key ##
PrivateKey = $private

## Wireguard server port ##
ListenPort = $wg_udpport

[Peer]
## Peer's wireguard public key ##
PublicKey=$peerpublickey
 
## Peer's wireguard ip address ##
AllowedIPs = 172.16.253.2/32
EOF

# Configure IPv4 forwarding
wg_conf='/etc/sysctl.d/10-wireguard.conf'
echo 'net.ipv4.ip_forward=1' >> $wg_conf

# Configure IPv6 forwarding 
echo 'net.ipv6.conf.all.forwarding=1' >> $wg_conf

# Reload changes using the sysctl command #
sysctl -p /etc/sysctl.d/10-wireguard.conf

# Start Wireguard
systemctl start wg-quick@wg0
systemctl enable wg-quick@wg0

printf "\n*** Verifying wireguard status ***\n"
systemctl status wg-quick@wg0

printf "\n*** Verifying interface wg0 configuration ***\n"
wg showconf wg0

printf "\n$0 has completed\n"
