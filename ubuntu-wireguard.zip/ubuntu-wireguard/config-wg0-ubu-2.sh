#!/bin/bash
# config-wg0-ubu-2.sh
# usage: this need to be called with sudo
# description: Creates a wireguard public key and wireguard private key
# and then writes part of the wg0.conf. It can not write
# the entire wg0.conf because it does not know the client public key.
# Lastly, it configures IP forwarding for subnets behind this server.

set -e

if [ "$EUID" -ne 0 ] ; then
  printf "Please run this as root\n"
  exit 1
fi
if [ -z "$1" ] ; then
  printf "this script requires peer's ip address\n"
  exit 1
fi
if [ -z "$2" ] ; then
  printf "this script requires peer's HTTP port\n"
  exit 1
fi
if [ -z "$3" ] ; then
  printf "his script requires peer's public key filename\n"
  exit 1
fi

peer_ip=$1
peer_tcp="$peer_ip:$2"
publickey_basename=$3
wg_udpport=51820

peer_url="http://$peer_tcp/$publickey_basename"
printf "\n*** Trying to connect to $peer_url ***\n"
peerpublickey=$(wget -q --connect-timeout=5 --tries=1 -O - $peer_url)

if [ -z "$peerpublickey" ] ; then
    echo "ERROR: unable to connect to $peer_tcp"
    exit 1
else
    printf "\n*** Successfully retrieved peer's public key ***\n"
fi

# Use bash command substitution
private=$(cat /etc/wireguard/privatekey)

# Add allow for wireguard udp port
printf "\n*** Adding new ufw allow rules ***\n"
ufw allow $wg_udpport/udp comment "Wireguard UDP Port"
sudo ufw status numbered verbose

# create a here document to create wg0.conf
cat << EOF > /etc/wireguard/wg0.conf
[Interface]
## This client's wireguard (wg0) ip address ##
Address = 172.16.253.2/24

## Wireguard client's private key ##
PrivateKey = $private

### Wireguard client port has
### No ListenPort 
 
[Peer]
## Wireguard Server Public Key ##
PublicKey = $peerpublickey
 
## set ACL ##
AllowedIPs = 172.16.253.1/32,192.168.81.0/24,10.99.1.0/24
 
## Wireguard Server's public IPv4/IPv6 address and port ##
Endpoint = $peer_ip:$wg_udpport
 
##  Key connection alive ##
PersistentKeepalive = 15
EOF

# Restart Wireguard
systemctl start wg-quick@wg0
systemctl enable wg-quick@wg0

printf "\n*** Verifying wireguard status ***\n"
systemctl status wg-quick@wg0

printf "\n*** Verifying interface wg0 configuration ***\n"
wg showconf wg0

printf "\n*** Routes allowed from wireguard vpn via wg0.conf ***\n"
ip route show | grep wg0

printf "\n$0 has completed\n"
