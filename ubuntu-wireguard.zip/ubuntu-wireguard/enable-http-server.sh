#!/bin/bash
# enable-http-server.sh
# usage: ./http-server-enable.sh 'interface_name' 'port'
# description: start python http server in the background

set -e
if [ "$EUID" -eq 0 ] ; then
  printf "This script can not be run as sudo\n"
  exit 1
fi
if [ -z "$1" ] ; then
  printf "this script requires an ip interface name\n"
  exit 1
fi
if [ -z "$2" ] ; then
  printf "this script requires tcp port\n"
  exit 1
fi

http_ip=$(ip a show $1 | awk '/inet / { print $2 }' | sed 's#/24##')
tcp_port="$http_ip $2"
printf "\nStarting Python in the background at $tcp_port\n"
python3 -m http.server -d "/home/osboxes/wireguard" -b $tcp_port &
python3_pid=$(pidof -s python3)

printf "\n\n"
read -p "Press enter to continue:  "

printf "\n    Started HTTP server with pid $python3_pid and EUID of $EUID\n"
printf "\n$0 has completed\n"
