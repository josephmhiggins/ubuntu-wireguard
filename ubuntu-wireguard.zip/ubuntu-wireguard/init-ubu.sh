#!/bin/bash
# init-ubu.sh
# Precondition: In a console session on Ubuntu 23.10:
#     sudo apt update -y
#     sudo apt install openssh-server -y
# Description:
#     Move /etc/netplan/50-cloud-init.yaml out of the way
#     Enable the ufw but permit ssh
#     sudo apt install keychain -y
#     sudo apt install ssh-askpass -y
#     Remove the default unattended_upgrades
#     Configure Ubuntu to only ask for ssh passphrase 1x per reboot 

set -eu

if [ "$EUID" -ne 0 ] ; then
  printf "Please run this as root\n"
  exit 1
fi

old_127='127.0.1.1 osboxes'
new_127="127.0.1.1 $(hostname) $(hostname -s)"
sed -i.original "s/$old_127/$new_127/g" /etc/hosts
printf "*** Modified /etc/hosts ***\n"
grep "$new_127" /etc/hosts

printf "\n*** Creating a Heredoc for verify_ping.sh ***\n"
cat << 'EOF' > verify_ping.sh
#!/bin/bash
# verify_ping.sh

function verify_ping () {
  remote=$1
  remote_ip=$2

  printf "\n*** Trying to ping $remote at $remote_ip ***\n"
  if ping -c 1 $remote_ip > /dev/null 2>&1 ; then
    printf "SUCCESS: Ping to $remote at $remote_ip was successful\n"
  else
    printf "ERROR: Ping to $remote $remote_ip failed\n"
    exit 1
  fi
}
EOF

if [[ -f verify_ping.sh ]] ; then 
  chmod -v +x verify_ping.sh
  chown -v osboxes:osboxes verify_ping.sh
  printf "\n*** Created verify_ping.sh ***\n"
  ls -1l verify_ping.sh
fi

archive=/etc/netplan/archive
if [[ ! -d "$archive" ]] ; then
  mkdir -v -p $archive
fi

printf "\n"

yaml_01='/etc/netplan/01-network-manager-all.yaml.original'
if [[ -f "$yaml_01" ]] ; then
  archive_01="$archive/01-network-manager-all.yaml.original"
  printf "*** Moving $yaml_01 to $archive_01 ***\n"
  mv -v $yaml_01 $archive_01
fi
yaml_50=/etc/netplan/50-cloud-init.yaml
if [[ -f "$yaml_50" ]] ; then
  chmod -v 600 $yaml_50
  archive_50="$archive/50-cloud-init.yaml.orginal"
  printf "*** Moving $yaml_50 to $archive_50 ***\n"
  mv -v $yaml_50 $archive_50
fi

printf "***Enabling ufw logging ***\n"
sudo ufw logging on

printf "\n*** Allowing ssh through ufw ***\n"
ufw allow 22/tcp comment "SSH Server"
printf "\n**** Enabling ufw ****\n"
ufw enable

printf "\n\n*** Removing ubuntu unattended-upgrades ***\n"
myName='/usr/share/unattended-upgrades/unattended-upgrade-shutdown'
set +e
myPID=$(pgrep -f $myName)
set -e
if [ -n "$myPID" ] ; then
    printf "killing $myName\n"
    kill -15 $myPID
    read -p "Hit enter to continue..."
fi

unattended='/etc/apt/apt.conf.d/20auto-upgrades'
rm -v $unattended
cat << EOF > $unattended
APT::Periodic::Update-Package-Lists "0";
APT::Periodic::Unattended-Upgrade "0";
EOF

printf "\n*** The NEW contents of 20auto-upgrades is: ***\n"
cat $unattended

x=$(logname)
home="/home/osboxes"
bashrc="/home/osboxes/.bashrc"

printf "\n*** Installing keychain via apt ***\n"
apt install keychain -y
printf "\n*** Installing ssh-askpass via apt ***\n"
apt install ssh-askpass -y

new_ssh=/home/osboxes/.ssh/config
if [ ! -f "$new_ssh" ] ; then
    etc_ssh=/etc/ssh/ssh_config
    printf "\n*** Copying $etc_ssh to $new_ssh ***\n"
    cp -v $etc_ssh $new_ssh
    chown osboxes:osboxes $new_ssh
    chmod 600 $new_ssh
    cp -v $new_ssh $new_ssh.original
    chown osboxes:osboxes $new_ssh.original
    chmod 600 $new_ssh.original
fi

sed -i 's|^#.*25519|    IdentityFile ~/.ssh/id_ed25519|g' $new_ssh
printf "\n*** Visual check of id_ed25519 line ***\n"
grep 'IdentityFile ~/.ssh/id_ed25519' $new_ssh

# Backup current .bashrc file
printf "\n*** Backing up current $bashrc ***\n"
backup=$bashrc'_'$(date +%Y%m%d%H%M%S)
cp -v $bashrc $backup
chown osboxes:osboxes $backup
printf "\n*** Appending new code to $bashrc ***\n"
cat << 'EOF' >> $bashrc

# *** Automate ssh keys loading into shell ***
# Loading ssh key id_ed25519 into shell
keychain id_ed25519
# myhostname_with_suffix=$(uname -n)-sh
source ~/.keychain/$(uname -n)-sh
# Verify ssh key id_ed25519 loaded into shell
str=$(keychain -l)  
if [[ -z "$str" ]] ; then
  printf "ERROR: $bashrc did not load ssh key id_ed25519 into the shell\n"
  exit 1
fi
# End Loading ssh key id_ed25519 into shell
EOF

printf "\n*** Test the script by logging out and then logging in ***\n"
printf "*** At login, enter the passprhrase gns3, then logout  ***\n"
printf "*** At login again, no passphrase should be required   ***\n\n"
printf "\n$0 has completed\n"
