#!/bin/bash
# install-libvirt-virbr1-nat.sh
# Install virsh nat network as virbr1-nat and as bridge virbr1
# and attached to interface ens5
# Rollback as superuser is done via:
#   sudo brctl delif virbr1 ens5
#   sudo virsh net-destroy virbr1-nat
#   sudo virsh net-undefine virbr1-nat
#   sudo brctl show
#   sudo rm /var/lib/libvirt/dnsmasq/virbr1.*
#
# Usage: sudo ./install-virbr1-nat.sh '10.99.1' '.128' '01:b4:80'

set -eu

if [ "$EUID" -ne 0 ] ; then
  printf "Please run this as root\n"
  exit 1
fi
if [ -z "$1" ] ; then
  printf "ERROR: this script requires the 1st 3 octets of ip address\n"
  exit 1
fi
if [ -z "$2" ] ; then
  printf "ERROR: this script requires the last 3 octets of mac address\n"
  exit 1
fi
if [ -z "$3" ] ; then
  printf "ERROR: this script requires the last octet of start dhcp pool\n"
  exit 1
fi

# *** Reflecting paramaters back to user
bridge_ip="'$1.1'"
mac="'52:54:00:$2'"
range_start="'$1.$3'"
range_end="'$1.254'"
printf "\n*** virbr1 ip address:                  $bridge_ip ***\n"
printf "*** virbr1 mac address:                 $mac ***\n"
printf "*** virbr1 dhcp range start ip address: $range_start ***\n"
printf "*** virbr1 dhcp range end ip address:   $range_end ***\n"

# *** Install a libvirt network xml definition
xml_base='virbr1-nat.xml'
xml='/etc/libvirt/qemu/networks/'$xml_base
uuid=$(uuidgen -r)
cat << EOF > $xml
<network>
  <name>virbr1-nat</name>
  <uuid>$uuid</uuid>
  <forward mode='nat'>
    <nat>
      <port start='1024' end='65535'/>
    </nat>
  </forward>
  <bridge name='virbr1' stp='on' delay='0'/>
  <mac address=$mac/>
  <ip address=$bridge_ip netmask='255.255.255.0'>
    <dhcp>
      <range start=$range_start end=$range_end/>
    </dhcp>
  </ip>
</network>
EOF
printf "\n*** Added $xml ***\n"
ls -1l $xml

# *** Install a systemd service: attach-ens5-to-virbr1.service
attach_s='/etc/systemd/system/attach-ens5-to-virbr1.service'
cat << EOF > $attach_s
[Unit]
Description=Attach ip link ens5 to bridge virbr1
BindsTo=sys-subsystem-net-devices-virbr1.device
After=sys-subsystem-net-devices-virbr1.device

[Service]
ExecStart=/usr/bin/attach-ens5-to-virbr1.sh

[Install]
WantedBy=multi-user.target
EOF
printf "\n*** Added $attach_s ***\n"
ls -1l $attach_s

# *** Install a script to run by systemd: attach-ens5-to-virbr1.service
attach_d=/usr/bin/attach-ens5-to-virbr1.sh
cat << 'EOF' > $attach_d
#!/bin/bash
# /usr/bin/attach-ens5-to-virbr1.sh
set -e

# test for substring master virbr1
str=$(ip -d link show ens5)
if [[ "$str" != *"master virbr1"* ]] ; then 
  printf "*** Adding ens5 to virbr1 ***\n"
  brctl addif virbr1 ens5
  brctl show | grep virbr1
fi
ip link set ens5 up
ip link set virbr1 up
EOF
chmod +x $attach_d
printf "\n*** Added $attach_d ***\n"
ls -1l $attach_d

printf "\n*** Validating $xml ***\n"
virt-xml-validate $xml
printf "*** Initializing vibr1-nat defined from $xml_base ***\n\n"
virsh net-define $xml
virsh net-start 'virbr1-nat'
virsh net-autostart virbr1-nat
printf "\n*** Listing all virsh networks ***\n"
virsh net-list --all
printf "\n*** Specific virsh info for virbr1-nat ***\n"
virsh net-info virbr1-nat
printf "\n*** Listing dnsmaq status for virbr1-nat ***\n"
pgrep -af 'libvirt/dnsmasq/virbr1-nat.conf'
printf "\n*** dnmasq virbr1 files including dhcp lease files .status ***\n"
ls -1l /var/lib/libvirt/dnsmasq/virbr1*

current_iptables='/home/osboxes/iptables-post-virbr1-install.txt'
iptables -L -n -v --line-numbers > $current_iptables
chown osboxes:osboxes $current_iptables
printf "\n*** Sent iptables to $current_iptables\n ***"
ls -1l $current_iptables

printf "\n*** Note: It may take a several seconds for virbr1\n"
printf "          to go UP because of Spanning-Tree Protocol\n"

systemctl start attach-ens5-to-virbr1
printf "\n*** Status of bridge virbr0 and virbr1 ***\n"
brctl show

printf "\n$0 has completed\n"
