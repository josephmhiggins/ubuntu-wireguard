#!/bin/bash
# install-libvirt.sh
# This need to be called with sudo by user ubuntu.
# This installs
#   all the packages to support libvirt.
#   a systemd service: attach-ens4-to-virbr0.service
#   a script to be called by the service: attach-ens4-to-virbr0.sh
# This backups iptables at various times during this script
#
set -eu

if [ "$EUID" -ne 0 ] ; then
  printf "Please run this as root\n"
  exit 1
fi

function write_iptables() {
  current_iptables=$1
  iptables -v -L --line-numbers > $current_iptables
  chown osboxes:osboxes $current_iptables
  printf "\n*** Sent iptables to $current_iptables ***\n"
  ls -1l $current_iptables
}

write_iptables '/home/osboxes/iptables-pre-libvirt-install.txt'

printf "\n**************************************************\n"
printf "    Running apt update and installing:\n"
printf "        libvirt-clients\n"
printf "        bridge-utils\n"
printf "        qemu-system-x86\n"
printf "        libvirt-daemon-system\n"
printf "\nThis will take at LEAST 15 minutes\n"
printf "\n**************************************************\n"
read -p "Press enter to continue...."

printf "\n*** Running apt update ***\n"
apt update -y
printf "\n*** Installing libvirt-clients via apt ***\n"
apt install libvirt-clients -y
printf "\n*** Installing bridge-utils via apt ***\n"
apt install bridge-utils -y
printf "\n*** Installing qemu-system-x86 via apt ***\n"
apt install qemu-system-x86 -y
printf "\n*** Installing libvirt-daemon-system via apt ***\n"
apt install libvirt-daemon-system -y
printf "\n*** Re-running apt update ***\n"
apt update -y
printf "\n*** Running apt autoremove ***\n"
apt autoremove -y

printf "\n\n*** Adding user osboxes to groups libvirt and kvm ***\n"
usermod -aG libvirt osboxes
usermod -aG kvm osboxes

printf "\n*** Enable IPv4 and IPv6 forwarding ***\n"
echo 'net.ipv4.ip_forward=1' >> /etc/sysctl.conf
echo 'net.ipv6.conf.all.forwarding=1' >> /etc/sysctl.conf
printf "\n*** Updated sysctl settings ***\n"
sysctl -p

printf "\n*** Enabling libvirtd at startup ***\n"
systemctl enable libvirtd

write_iptables '/home/osboxes/iptables-post-libvirt-install.txt'

# *** Install a systemd service: attach-ens4-to-virbr0.service
attach_s='/etc/systemd/system/attach-ens4-to-virbr0.service'
cat << EOF > $attach_s
[Unit]
Description=Attach ip link ens4 to bridge virbr0
BindsTo=sys-subsystem-net-devices-virbr0.device
After=sys-subsystem-net-devices-virbr0.device

[Service]
ExecStart=/usr/bin/attach-ens4-to-virbr0.sh

[Install]
WantedBy=multi-user.target
EOF

# *** Install a script to run by systemd: attach-ens4-to-virbr0.service
attach_d=/usr/bin/attach-ens4-to-virbr0.sh
cat << 'EOF' > $attach_d
#!/bin/bash
# /usr/bin/attach-ens4-to-virbr0.sh
set -e

# test for substring master virbr0
str=$(ip -d link show ens4)
if [[ "$str" != *"master virbr0"* ]] ; then
  printf "*** Adding ens4 to virbr0 ***\n"
  brctl addif virbr0 ens4
  brctl show | grep virbr0
fi
ip link set ens4 up
ip link set virbr0 up
EOF

chmod +x $attach_d
printf "\n*** Enabling attach-ens4-to-virbr0.service at boot ***\n"
systemctl enable attach-ens4-to-virbr0

printf "\n*** Note: It may take a several seconds for virbr0   ***\n"
printf "***       to go UP because of Spanning-Tree Protocol ***\n"

systemctl start attach-ens4-to-virbr0

printf "\n*** Status of bridge virbr0 ***\n"
brctl show

printf "\n$0 has completed\n"
