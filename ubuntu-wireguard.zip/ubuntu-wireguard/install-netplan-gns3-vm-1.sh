#!/bin/bash
# install-netplan-gns3-vm-1.sh
# This need to be called with sudo.

set -eu

if [ "$EUID" -ne 0 ] ; then
  printf "Please run this as root\n"
  exit 1
fi

printf "\n*** Permitting DNS through ufw ***\n"
sudo ufw allow from 192.168.92.2 to any port 53

printf "\n*** Adding non-libvirt host to hosts file ***\n"
echo '192.168.81.8 gns3-pyats-8' >> /etc/hosts

printf "\n***Creating a here document for 20.yaml ***\n"
new_yaml=/home/osboxes/20.yaml
cat << EOF > $new_yaml
network:
    renderer: networkd
    version: 2
    ethernets:
        ens8:
            dhcp4: false
            dhcp6: false
            addresses: [192.168.81.1/24]
        ens9:
            dhcp4: false
            dhcp6: false
            addresses: [192.168.91.1/24]
            routes:
                - to: 192.168.92.0/24
                  via: 192.168.91.9
EOF

chmod 600 $new_yaml
mv $new_yaml /etc/netplan/20.yaml
netplan apply

printf "\n*** IPv4 address of interface ens8 ***\n"
ip address show ens8

printf "\n*** IPv4 address of interface ens9 ***\n"
ip address show ens9

source verify_ping.sh

function verify_tcp() {
    url="http://$2:8080/x"
    printf "\n*** Trying to connect to $1 at $url ***\n"
    val=$(wget -q --connect-timeout=5 --tries=1 -O - $url)
    if [ "$1" != "$val" ] ; then
        printf "ERROR: failed to retrieve file x from $1\n"
    else
        printf "SUCCESS: HTTP retrieved $val from $1\n"
    fi
}

verify_ping frr-9 192.168.91.9
verify_ping gns3-pyats-4 192.168.122.4
verify_tcp gns3-pyats-4 192.168.122.4
verify_ping gns3-pyats-5 10.99.1.18
verify_tcp gns3-pyats-5 10.99.1.18
verify_ping gns3-pyats-6 10.99.1.212
verify_tcp gns3-pyats-6 10.99.1.212
verify_ping gns3-pyats-8 192.168.81.8
verify_tcp gns3-pyats-8 192.168.81.8

printf "\n*** ubu-2 verification is postponed until it is configured ***\n"
printf "\n$0 has completed successfully\n"
