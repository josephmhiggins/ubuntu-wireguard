#!/bin/bash
# install-netplan-ubu-2.sh
# This need to be called with sudo.

set -eu

if [ "$EUID" -ne 0 ] ; then
  printf "Please run this as root\n"
  exit 1
fi

# create a here document for 20.yaml
new_yaml=/home/osboxes/20.yaml
cat << EOF > $new_yaml
network:
  renderer: networkd
  version: 2
  ethernets:
    ens9:
      dhcp4: false
      dhcp6: false
      addresses: [192.168.92.2/24]
      routes:
        - to: 192.168.91.0/24
          via: 192.168.92.9
EOF

chmod 600 $new_yaml
mv $new_yaml /etc/netplan/20.yaml
netplan apply

printf "\n"
printf "\n*** IPv4 address of interface ens9 ***\n"
ip address show ens9

source verify_ping.sh

verify_ping frr-2 192.168.92.9
verify_ping gns3-vm-1 192.168.91.1

printf "\n$0 has completed successfully\n"
