#!/bin/bash
# install-wireguard.sh
# usage: this need to be called with sudo
# Installs wireguard and creates two wireguard directories.

set -e

if [ "$EUID" -ne 0 ] ; then
  printf "Please run this as root\n"
  exit 1
fi

# clean up from wireguard-install-openssh
printf "*** Backing up /etc/ssh/sshd_config ***\n"
sshd_original='/etc/ssh/sshd_config.original'
if [ ! -f "$sshd_original" ] ; then
  cp -v /etc/ssh/sshd_config $sshd_original
  chmod -v a-w $sshd_original
fi

printf "*** Running apt update ***\n"
apt update -y

etc_wg_dir="/etc/wireguard"
public_wg_dir="/home/osboxes/wireguard"

printf "\n*** Creating directory $etc_wg_dir ***\n"
if [ ! -d "$etc_wg_dir" ] ; then
  mkdir -v -p -m 0700 $etc_wg_dir
fi

# make publically accessible wireguard directory
printf "\n*** Creating directory $$public_wg_dir ***\n"
if [ ! -d "$public_wg_dir" ]; then
  mkdir -v -p $public_wg_dir
fi
chown -v osboxes:osboxes $public_wg_dir

# install wireguard
printf "\n*** Installing wireguard via apt ***\n"
apt install wireguard -y

# test if wireguard was installed
if ! [ -x "$(command -v wg)" ]; then
  printf "ERROR: wireguard installation failed\n"
  exit 1
fi

printf "\n$0 has completed successfully\n"
