#!/bin/bash
# usage: this need to be called with sudo
# description: copy the publickey to a publically accessible location
set -e
if [ "$EUID" -ne 0 ] ; then
  printf "Please run this as root\n"
  exit 1
fi
if [ -z "$1" ] ; then
  printf "this script requires an ip interface name\n"
  exit 1
fi
if [ -z "$2" ] ; then
  printf "this script requires tcp port\n"
  exit 1
fi
if [ -z "$3" ] ; then
  printf "this script requires a string with the basename of public key\n"
  exit 1
fi

http_ip=$(ip a show $1 | awk '/inet / { print $2 }' | sed 's#/24##')
http_port=$2
public_basename=$3

etc_wg_dir="/etc/wireguard"
wg_udpport=51820

# Create keys
cd $etc_wg_dir
# set file mode creation mask to make files executable
orig_mask=$(umask)
umask 077
# creates 2 files: privatekey and $public_basename
wg genkey | tee privatekey | wg pubkey > $public_basename
# Use bash command substitution
private=$(cat privatekey)
public=$(cat $public_basename)
umask $orig_mask
cd /home/osboxes

etc_key="$etc_wg_dir/$public_basename"
public_key="/home/osboxes/wireguard/$public_basename"
printf "\n*** Copying $etc_key to $public_key ***\n"
# copy publickey-fullpath to osboxes publicly accessible directory
cp -v $etc_key $public_key

# change ownership of file from root to osboxes and group osboxes
printf "\n*** Modifying ownership and readability of $public_key ***\n"
chown -v osboxes:osboxes $public_key
chmod -v ugo+r $public_key

printf "\n*** Adding new ufw allow rules for Wireguard HTTP ***\n\n"
ufw allow from any proto tcp\
          to $http_ip port $http_port comment "Wireguard HTTP"
sudo ufw status numbered verbose

printf "\n$0 has completed\n"
