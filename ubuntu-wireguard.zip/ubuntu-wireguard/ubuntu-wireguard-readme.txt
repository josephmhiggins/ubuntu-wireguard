Preface: To upload files, ssh into a device and copy and
paste text into a file open in nano, vi, or vim and
save them in the respective filenames in the user 'ubuntu' home directory.
I use nano here, so replace nano with vi or vim is desired.



A. GUI Baseline Configuration - This will be by other sections later.
    Note: At least 10 minutes to complete this section.
    1. power-screen blank-never
    2. notification do not disturb
    3. Enter terminal in search and select terminal to open it
    4. Left click on terminal in dash and select Pin to dash
    5. The rest of the commands are entered in the terminal
        cp .bashrc .bashrc.original
        sudo su
        # password osboxes.org
        # next command depends on whether this is for ubu-3, ubu-2, or gsn3-vm-1
        hostnamectl set-hostname ubu-3.wg.test
        # or 
        hostnamectl set-hostname ubu-2.wg.test
        # or
        hostnamectl set-hostname gns3-vm-1.wg.test
        #
        apt update -y
        apt install openssh-server -y
        systemctl enable ssh
        apt install openvswitch-switch-dpdk -y   
        systemctl start systemd-networkd
        systemctl enable systemd-networkd
        cd /etc/netplan
        yaml_01='01-network-manager-all.yaml'
        chmod 600 $yaml_01
        mv $yaml_01 $yaml_01.original
        touch 01.yaml
        chmod 600 01.yaml
        ### Using nano to create the file 01.yaml ###
        nano 01.yaml

network:
  version: 2
  renderer: networkd
  ethernets:
    ens3:
      dhcp4: true
### To save the file in nano:
Ctrl-O
Ctrl-X
        ### End of using nano to create the file 01.yaml ###
        netplan apply
        ip address show ens3
        cd /etc/ssh
        ed25='ssh_host_ed25519_key'
        mv $ed25 $ed25.original
        mv $ed25.pub $ed25.pub.original
        # NO PASSPHRASE HERE (just hit enter when prompted)
        ssh-keygen -f ./$ed25 -t ed25519
        # Leave root
        exit
        ### Last command as user osboxes ###
        ### osboxes:osboxes$
        ### Note: keyphrase gns3 is in clear text                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         
        ssh-keygen -f /home/osboxes/.ssh/id_ed25519 -t ed25519 -N gns3
    6. In Gui: Power - Log Out

Note: The rest of the configuration is done via ssh from the GNS3 VM or a
    linux host without the GNS3 VM. If you are using the GNS3 VM, then
    you have to ssh into the GNS3 VM and open up three terminal:
        1 tab in a terminal for ubu-3,
        1 tab in a terminal for gns3-vm-1, accessed via ubu-3
        1 tab in a terminal for ubu-2, accessed via ubu-3
B. Install and Configure Libvirt on ubu-3
    Note: Time to complete is about 35 minutes
    1. start ubu-3
    2. Perform GUI Baseline Configuration for ubu-3
    3. ssh into ubu-3 from your host or the GNS3 VM
        # Optional: on your host or the GNS3 VM
        #   add ubu3 to /etc/hosts
        #   create your own passphrase on your host or the GNS3 VM
        #   ssh-keygen -f /home/osboxes/.ssh/id_ed25519 -t ed25519
        #   ssh-copy-id -f -i ~/.ssh/id_ed25519.pub osboxes@ubu-3
        ssh osboxes@ubu-3
    2. On ubu-3, upload by copying and pasting into nano the ensuing files:
        Note: Installing libvirt takes at least 15 minutes    
        nano init-ubu.sh
        chmod +x init-ubu.sh
        nano install-libvirt.sh
        chmod +x install-libvirt.sh
        nano install-libvirt-virbr1-nat.sh
        chmod +x install-libvirt-virbr1-nat.sh
        nano verify-libvirt.sh
        chmod -v +x verify-libvirt.sh        
    3. On ubu-3 at the terminal enter:
        sudo ./init-ubu.sh
        source .bashrc
        # enter passphrase gns3
        logout
        # re-ssh into ubu-3 from your host or the GNS3 VM
        sudo ./install-libvirt.sh
        logout
        # re-ssh into ubu-3 from your host or the GNS3 VM

        # *** Add ubu-2 as a dhcp host ********************************* #
virsh net-update default add ip-dhcp-host \
"<host name='ubu-2' ip='192.168.123.2'/>" --live --config
sudo cp /etc/hosts /etc/hosts_$(date +%Y%m%d%H%M%S)
sudo bash -c "echo '192.168.123.2 ubu-2' >> /etc/hosts"
        # *** End ubu-2 as a dhcp host ************************************* #

        # install virbr1-nat with
        #   ip address 192.168.124.1 and subnet 192.168.124.0/24
        #   mac address of 52:54:00:03:b4:80 Note: "03" is for ubu-3
        #   dhcp ip pool start range 192.168.124.128        
        sudo ./install-libvirt-virbr1-nat.sh 192.168.124 '03:b4:80' '128'

        # *** Add gns3-vm-1 as a dhcp host ********************************* #
virsh net-update virbr1-nat add ip-dhcp-host \
"<host name='gns3-vm-1' ip='192.168.124.2'/>" --live --config
sudo cp /etc/hosts /etc/hosts_$(date +%Y%m%d%H%M%S)
sudo bash -c "echo '192.168.124.2 gns3-vm-1' >> /etc/hosts"
        # *** End gns3-vm-1 as a dhcp host ********************************* #

    4. Verification is done inline but can be re-checked by:
        sudo ./verify-libvirt.sh default virbr0 ens4
        sudo ./verify-libvirt.sh virbr1-nat virbr1 ens5
        # Optional to print a VERY LONG list of bridge details in JSON format
        ip -j -p -d link show virbr0
        ip -j -p -d link show virbr1

C. Install and Configure Libvirt on gns3-vm-1
    Note: This takes at least 35 minutes
    1. In the GNS3 topology, start gns3-vm-1
    2. Perform the section A. GUI Baseline Configuration
    3. ssh into ubu-3 from the GNS3 VM or your host
    4. from ubu-3, ssh into gns3-vm-1 via these commands: 00:08
        ssh-copy-id -f -i ~/.ssh/id_ed25519.pub osboxes@gns3-vm-1
        # yes/no/[fingerprint])? yes
        # osboxes@192.168.124.2's password:osboxes.org
        ssh osboxes@gns3-vm-1
        # Enter passphrase gns3 if requested
    6. On gns3-vm-1, upload by copying and pasting into nano the ensuing files:
        nano init-ubu.sh
        chmod -v +x init-ubu.sh
        nano install-libvirt.sh
        chmod -v +x install-libvirt.sh
        nano install-libvirt-virbr1-nat.sh
        chmod -v +x install-libvirt-virbr1-nat.sh
        nano verify-libvirt.sh
        chmod -v +x verify-libvirt.sh        
    7. On gns3-vm-1 at the terminal enter:
        sudo ./init-ubu.sh
        source .bashrc
        # enter passphrase gns3
        logout
        # re-ssh into gns3-vm-1 from ubu-3
        sudo ./install-libvirt.sh
        logout
        # re-ssh into gns3-vm-1 from ubu-3
        sudo ./install-libvirt-virbr1-nat.sh '10.99.1' '01:b4:80' '128'

        # Note: parameters to install-libvirt-virbr1-nat.sh are used for:
        #       ip address 10.99.1.1 and subnet 10.99.1.0/24
        #       mac address of 52:54:00:01:b4:80 Note: "01" is for gns3-vm-1
        #       dhcp ip pool start range 192.168.123.128

        # *** Add gns3-pyats-4 as a dhcp host **************************** #
virsh net-update default add ip-dhcp-host \
"<host name='gns3-pyats-4' ip='192.168.122.4'/>" --live --config
virsh net-dumpxml default | grep pyats-4
sudo cp /etc/hosts /etc/hosts_$(date +%Y%m%d%H%M%S)
sudo bash -c "echo -e '\n*** Custom hosts ***' >> /etc/hosts"
sudo bash -c "echo -e '192.168.122.4 gns3-pyats-4' >> /etc/hosts"
        # *** End gns3-pyats-4 as a dhcp host **************************** #

        # *** Add gns3-pyats-5 as a dhcp host **************************** #
virsh net-update virbr1-nat add ip-dhcp-host \
"<host name='gns3-pyats-5' ip='10.99.1.18'/>" --live --config
virsh net-dumpxml virbr1-nat | grep pyats-5
sudo cp /etc/hosts /etc/hosts_$(date +%Y%m%d%H%M%S)
sudo bash -c "echo '10.99.1.18 gns3-pyats-5' >> /etc/hosts"
        # *** End gns3-pyats-5 as a dhcp host **************************** #

        # *** Add gns3-pyats-6 as a dhcp host **************************** #
virsh net-update virbr1-nat add ip-dhcp-host \
"<host name='gns3-pyats-6' ip='10.99.1.212'/>" --live --config
virsh net-dumpxml virbr1-nat | grep pyats
sudo cp /etc/hosts /etc/hosts_$(date +%Y%m%d%H%M%S)
sudo bash -c "echo '10.99.1.212 gns3-pyats-6' >> /etc/hosts"
        # *** End gns3-pyats-6 as a dhcp host **************************** #
    3. Verification is done inline but can be re-checked by:
        sudo ./verify-libvirt.sh default virbr0 ens4
        sudo ./verify-libvirt.sh virbr1-nat virbr1 ens5
D. Configure Networking on gns3-vm-1
    Note: This section takes about 20 minutes
    1. Start all the dockers and configure networking according to .txt files
        Note; Wait until all the dockers get an ip address (about 2 minutes)
              Use "ifconfig eth0"
    2. On all the gns3-pyats dockers console connection: copy and paste:
        hostname > x
        # start python3 http server in the background
        python3 -m http.server 8080 &
        printf "\npython pid is " &&  pidof -s python3
        # hit enter to get rid of stale data    
    2. On gns3-vm-1: in the ssh session terminal enter
        nano install-netplan-gns3-vm-1.sh
        chmod +x install-netplan-gns3-vm-1.sh
        sudo ./install-netplan-gns3-vm-1.sh
    3. Verification is done inline during install, except for ubu-2
E. Configure Networking on ubu-2
    Note: This takes about 30 minutes to complete
    1. In the GNS3 topology, start ubu-2
    2. Perform the section A. GUI Baseline Configuration
    3. ssh into ubu-3 from the GNS3 VM or your host
    4. from ubu-3, ssh into ubu-2
        ssh-copy-id -f -i ~/.ssh/id_ed25519.pub osboxes@ubu-2
        # yes/no/[fingerprint])? yes
        # osboxes@192.168.123.2's password:osboxes.org
        ssh osboxes@ubu-2
    5. On ubu-2 at the terminal enter:
        nano init-ubu.sh
        chmod +x init-ubu.sh        
        nano install-netplan-ubu-2.sh
        chmod -v +x install-netplan-ubu-2.sh
    6. On ubu-2 at the terminal enter:
        sudo ./init-ubu.sh
        source .bashrc
        # Enter passphrase gns3
        logout
        # re-ssh into ubu-2 from ubu-3, no passphrase should be required
        sudo ./install-netplan-ubu-2.sh
    7. Verification is done inline when netplan is installed
F. Wireguard Installation on gns3-vm-1 and ubu-2
    hardcoded constants used on server (gns3-vm-1) and client (ubu-2) are:
    Note: Time to complete about 45 minutes
        udp port: 51820
        wireguard /etc directory: /etc/wireguard
        wireguard public directory: /home/osboxes/wireguard
        server_wg0_ip: 172.16.253.1
        client_wg0_ip: 172.16.253.2
    1. On gns3-vm-1 and ubu-2, upload and chmod the ensuing files:
        nano install-wireguard.sh
        chmod +x install-wireguard.sh
        nano publish-wireguard-key.sh
        chmod +x publish-wireguard-key.sh
        nano enable-http-server.sh
        chmod +x enable-http-server.sh
    2.  On gns3-vm-1 and ubu-2, run
        sudo ./install-wireguard.sh
        sudo ./publish-wireguard-key.sh 'ens9' '8080' 'ubu-2_gns3-vm-1'
        #****** No sudo here - it will not work with sudo *******
        ./enable-http-server.sh 'ens9' '8080'
        #********************************************************
    3. Start wireshark betweek frr-9 and ubu-2 to see wireguard packets
    4. On gns3-vm-1 (wireguard server),
        nano config-wg0-gns3-vm-1.sh
        chmod +x config-wg0-gns3-vm-1.sh
        sudo ./config-wg0-gns3-vm-1.sh '192.168.92.2:8080' 'ubu-2_gns3-vm-1'
    5. On ubu-2 (wireguard client), run
        nano config-wg0-ubu-2.sh
        chmod +x config-wg0-ubu-2.sh
        sudo ./config-wg0-ubu-2.sh '192.168.91.1' '8080' 'ubu-2_gns3-vm-1'
    6. Initial Verification
        Most of the verification is done inline.
        Start wireshark betweek frr-9 and ubu-2 to see wireguard packets
        The wireguard tunnel might take a few seconds to go UP.
        So after a few seconds:
            from ubu-2 ping 172.16.253.1 # gns3-vm-1 wg0 ip address
            from ubu-2 ping 192.168.81.8 # gns3-pyats-8
    7. Final Verification is done via ubu-2
        Note: From gn3-vm pings and http gets
              to all the gns3-pyats dockers need to be working.
              These are all previously tested in install-netplan-gns3-vm-1.sh
        
        ssh-copy-id -f -i ~/.ssh/id_ed25519.pub osboxes@172.16.253.1
        ssh osboxes@172.168.253.1

        # Upload and chmod pyats-verification-ubu-2.sh via nano
        nano verify-pyats-ubu-2.sh
        chmod +x verify-pyats-ubu-2.sh
        ./verify-pyats-ubu-2.sh
