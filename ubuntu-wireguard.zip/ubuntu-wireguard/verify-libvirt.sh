#!/bin/bash
# verify-libvirt.sh
# This need to be called with sudo by user ubuntu.
# This uses print commands to show attributes of virsh.

set -eu

if [ "$EUID" -ne 0 ] ; then
  printf "Please run this with sudo\n"
  exit
fi

if [ -z "$1" ] ; then
  printf "ERROR: this script requires the name of the virsh network\n"
  exit 1
fi
if [ -z "$2" ] ; then
  printf "ERROR: this script requires the name of the bridge\n"
  exit 1
fi
if [ -z "$3" ] ; then
  printf "ERROR: this script requires the name of the bridge\n"
  exit 1
fi

printf "\n\n***osboxes is a member of the following groups ***\n"
groups osboxes

printf "\n*** Checking status of dnsmasq ***\n"
pgrep -af 'libvirt/dnsmasq'

printf "\n*** Listing virsh networks ***\n"
virsh net-list --all

printf "\n*** The virsh $1 network information ***\n"
virsh net-info $1

printf "\n*** The virsh $1 network information in XML ***\n"
virsh net-dumpxml $1

printf "\n*** Verifying ethernet link $3 ***\n"
ip link show $3

printf "\n*** Verifying bridge link $2 ***\n"
ip link show $2

printf "\n*** Verifying bridge ip address $2 ***\n"
ip address show $2

printf "\n*** Verifying bridge $2  ***\n"
brctl show $2

printf "\n*** Verifying ipv4 forwarding in /etc/sysctl.conf ***\n"
sysctl -p

printf "\n$0 has completed\n"
