#!/bin/bash
# verify-pyats-ubu-2.sh

source verify_ping.sh
verify_ping gns3-pyats-8 192.168.81.8

function verify_ssh_tunnel() {
    url="$2/x"
    printf "\n*** Trying to connect to $1 at $url ***\n"
    val=$(wget -q --connect-timeout=5 --tries=3 -O - $url)
    if [ "$val" != "$1" ] ; then
        printf "ERROR: failed to retrieve file x from $1\n"
    else
        printf "SUCCESS: HTTP retrieved $val from $1\n"
    fi
}

py5='127.0.0.1:52005'
py6='127.0.0.1:52006'
py8='127.0.0.1:52008'
pkill -f $py5
pkill -f $py6
pkill -f $py8

ssh -fNL $py5:10.99.1.18:8080 osboxes@172.16.253.1
verify_ssh_tunnel gns3-pyats-5 $py5
pkill -f $py5

ssh -fNL $py6:10.99.1.212:8080 osboxes@172.16.253.1
verify_ssh_tunnel gns3-pyats-6 $py6
pkill -f $py6

ssh -fNL $py8:192.168.81.8:8080 osboxes@172.16.253.1
verify_ssh_tunnel gns3-pyats-8 $py8
pkill -f $py8

pref='Note: Lab is not designed for ubu-2'
printf "\n*** $pref to ping/tcp to gns3-pyats-4 ***\n"
printf "*** $pref to ping gns3-pyats-5 via ssh tunnelling ***\n"
printf "*** $pref to ping gns3-pyats-6 via ssh tunnelling ***\n"

printf "\n$0 has completed\n"

